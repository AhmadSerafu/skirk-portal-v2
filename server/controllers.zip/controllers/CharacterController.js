const genshindb = require("genshin-db");

class CharacterController {
  static getCharacters(req, res, next) {
    try {
      const { vision, weapon, nation, rarity } = req.query;

      const charNames = genshindb.characters("names", {
        matchCategories: true,
      });

      let characters = charNames
        .map((name) => {
          const character = genshindb.characters(name);
          if (!character || !character.images) return null;
          return {
            id: character.id,
            name: character.name,
            vision: character.elementText,
            weapon: character.weaponText,
            nation: character.region,
            rarity: character.rarity,
            images: {
              icon: character.images.mihoyo_icon,
              card: character.images.filename_iconCard?.trim()
                ? `https://enka.network/ui/${character.images.filename_iconCard}.png`
                : character.images.mihoyo_icon,
            },
          };
        })
        .filter(Boolean);

      if (vision)
        characters = characters.filter(
          (c) => c.vision?.toLowerCase() === vision.toLowerCase(),
        );
      if (weapon)
        characters = characters.filter(
          (c) => c.weapon?.toLowerCase() === weapon.toLowerCase(),
        );
      if (nation)
        characters = characters.filter(
          (c) => c.nation?.toLowerCase() === nation.toLowerCase(),
        );
      if (rarity)
        characters = characters.filter((c) => c.rarity === Number(rarity));

      res.status(200).json(characters);
    } catch (error) {
      next(error);
    }
  }

  static getCharacterById(req, res, next) {
    try {
      const { id } = req.params;

      const character = genshindb.characters(String(id));
      if (!character)
        throw { name: "NotFound", message: "Character not found" };

      const talents = genshindb.talents(character.name);
      const constellations = genshindb.constellations(character.name);

      console.log(
        "constellation image:",
        constellations?.images?.filename_constellation,
      );

      res.status(200).json({
        id: character.id,
        name: character.name,
        title: character.title,
        description: character.description,
        rarity: character.rarity,
        vision: character.elementText,
        weapon: character.weaponText,
        nation: character.region,
        affiliation: character.affiliation,
        birthday: character.birthday,
        constellation: character.constellation,
        cv: character.cv,
        costs: character.costs,
        skillTalents: talents
          ? [talents.combat1, talents.combat2, talents.combat3].filter(Boolean)
          : [],
        passiveTalents: talents
          ? [talents.passive1, talents.passive2, talents.passive3].filter(
              Boolean,
            )
          : [],
        constellations: constellations
          ? [
              constellations.c1,
              constellations.c2,
              constellations.c3,
              constellations.c4,
              constellations.c5,
              constellations.c6,
            ].filter(Boolean)
          : [],
        constellationImage: constellations?.images?.filename_constellation
          ? `https://enka.network/ui/${constellations.images.filename_constellation}.png`
          : null,
        images: {
          icon: character.images.mihoyo_icon,
          card: character.images.filename_iconCard?.trim()
            ? `https://enka.network/ui/${character.images.filename_iconCard}.png`
            : character.images.mihoyo_icon,
          portrait: character.images.cover1 || null,
          splash: character.images.filename_gachaSplash?.trim()
            ? `https://enka.network/ui/${character.images.filename_gachaSplash}.png`
            : null,
        },
      });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = CharacterController;
